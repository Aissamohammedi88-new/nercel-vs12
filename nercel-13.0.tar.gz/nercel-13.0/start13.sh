#!/usr/bin/env bash
# NERCEL 13 FORGE : lanceur avec auto-verification (stdlib uniquement)
set -e
cd "$(dirname "$0")"

# 1) le fichier doit compiler
python3 -m py_compile nercel13.py && echo "OK nercel13.py compile"

# 2) deja un nercel13 qui tourne ? on le remplace proprement
pkill -f "python3 nercel13.py" 2>/dev/null && sleep 1 || true

# 3) lancement + sonde /api/health (10 essais, 1 s d'intervalle)
nohup python3 nercel13.py > nercel13.log 2>&1 &
for i in 1 2 3 4 5 6 7 8 9 10; do
  sleep 1
  if curl -s -m 2 http://127.0.0.1:5067/api/health | grep -q '"ok"'; then
    echo "OK service UP : http://127.0.0.1:5067"
    echo "   logs : tail -f $(pwd)/nercel13.log"
    echo "   arret: pkill -f 'python3 nercel13.py'"
    exit 0
  fi
done

echo "ECHEC le service ne repond pas - extrait de nercel13.log :"
tail -5 nercel13.log
exit 1
