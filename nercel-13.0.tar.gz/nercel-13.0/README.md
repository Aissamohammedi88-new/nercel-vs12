# NERCEL 13 — FORGE

Dashboard temps réel **style Grafana** + **agents réels** + **scaffolds réels**
+ **catalogue d'agents open source**. Zéro dépendance : **stdlib Python
uniquement**, rien à installer.

## Lancer

```bash
bash start13.sh
```

Le lanceur compile le fichier, démarre le service et **vérifie lui-même** que
`/api/health` répond avant de dire OK. Puis ouvrir **http://127.0.0.1:5067**.

Arrêt : `pkill -f 'python3 nercel13.py'` (ou Ctrl+C si lancé au premier plan
avec `python3 nercel13.py`).

## Correctifs par rapport à la v11/v12 (ce que tu as demandé)

1. **Bug « JSON.parse: unexpected character at line 1 column 1 » — mort par
   construction.** Toutes les routes renvoient `application/json`, **y compris
   les 404 et les 500** (plus aucune page HTML d'erreur ne peut arriver au
   frontend). Côté navigateur, `api()` vérifie aussi que la réponse est du
   JSON avant de l'utiliser et affiche un toast explicite sinon.
2. **Scaffolds réparés et réels** : la route `/api/scaffolds` existe (GET,
   liste JSON) et le bouton **Scaffolds** crée de **vrais fichiers** sur
   disque dans `scaffolds13/<nom>/` — 8 modèles : Python CLI, lib Python,
   micro-service JSON, Flask, FastAPI, site statique, agent bot, data
   pipeline. Fix inclus : `{NAME}` dans les chemins de fichiers (le modèle
   lib créait un dossier littéral `{NAME}`).
3. **Port navigable** : 5067 (5060/5061 sont refusés par Chrome/Firefox —
   ports « unsafe » ; 5067 passe, comme le 5065 de la v12).
4. **Création d'agents connectée à l'open source** :
   - **Catalogue** de 12 vrais projets OSS avec liens GitHub réels : Aider,
     OpenHands, Open Interpreter, CrewAI, AutoGen, LangGraph, gpt-engineer,
     SWE-agent, Continue, Devika, Flowise, Dify (commande d'install incluse).
   - **Recommandation** : bouton *Recommander* qui matche ton objectif avec
     les blueprints locaux et les agents OSS (scoring déterministe, 100 %
     stdlib).
   - **Prompt optionnel** : texte libre compilé en vraies commandes shell
     (règles par mots-clés).
   - **Bridge Ollama local** (open source) : si Ollama tourne sur
     `127.0.0.1:11434`, il génère lui-même les commandes de l'agent, avec
     **garde-fou** (refus de `sudo`, `rm -rf /`, `mkfs`, `shutdown`…).
     S'il est absent : repli automatique sur les règles par mots-clés.
5. **Service auto-vérifié au démarrage** : `start13.sh` ne dit « OK » que
   quand `/api/health` répond.

## Ce que ça fait (hérité de la v12)

- **Métriques réelles** lues dans `/proc` : CPU % (delta `/proc/stat`),
  mémoire, disque, load, réseau ↓↑ — échantillonnées toutes les 5 s,
  graphiques canvas live.
- **Agents réels** : exécution `subprocess` avec timeout 120 s, code de
  sortie réel, sortie console visible (clique sur une exécution).
- **4 agents pré-installés** : `compile`, `tests`, `deps`, `docs`.
- **Créer / éditer / supprimer** des agents, intervalle auto (0 = manuel).
- **Persistance** : `nercel13_data.json` (agents + historique des runs +
  scaffolds créés).

## API (tout renvoie du JSON, même les erreurs)

| Route | Méthode | Effet |
|---|---|---|
| `/api/health` | GET | état du service |
| `/api/state` | GET | snapshot métriques + séries + agents + runs + scaffolds |
| `/api/catalog` | GET | catalogue OSS + blueprints locaux |
| `/api/scaffolds` | GET | liste des modèles de scaffolds |
| `/api/scaffolds/create` | POST | créer un projet réel (`{"tpl":"py-cli","name":"mon-projet"}`) |
| `/api/agents/create` | POST | créer un agent (nom, objectif, prompt, blueprint, intervalle, `use_ollama`) |
| `/api/agents/recommend` | POST | recommandation par objectif (`{"goal":"..."}`) |
| `/api/agents/<id>/run` | POST | lancer un agent |
| `/api/agents/<id>/update` | POST | modifier un agent |
| `/api/agents/<id>/delete` | POST | supprimer un agent |
| `/api/ollama/check` | POST | Ollama détecté ? quels modèles ? |
| toute autre route | GET/POST | **404 en JSON** `{"error": "route inconnue: ..."}` |

## Fichiers

- `nercel13.py` — tout le service (backend + dashboard embarqué)
- `start13.sh` — lanceur avec auto-vérification
- `tests/test_smoke.py` — test de base exécuté par l'agent `tests`
- `nercel13_data.json` — créé automatiquement (agents + runs + scaffolds)
- `scaffolds13/` — créé automatiquement (projets générés par Scaffolds)

## Configuration (variables d'environnement)

- `NERCEL13_PORT` (défaut `5067`), `NERCEL13_HOST` (défaut `127.0.0.1`),
  `NERCEL13_OLLAMA` (défaut `http://127.0.0.1:11434`).

## 100 % additif

Ce dossier ne touche à aucun fichier existant : pose-le où tu veux (par
exemple à côté de ta v10/v11/v12) et lance-le — tes autres versions restent
intactes. La v12 peut tourner en même temps (port 5065) : l'agent
`api-monitor` sonde justement les deux.
