#!/usr/bin/env python3
# ============================================================
#  NERCEL 13 "FORGE"  -  un seul fichier, 100% stdlib, zero install
#  Port 5067 - metriques reelles (/proc) - agents reels (subprocess)
#  Scaffolds reels (fichiers crees sur disque) - catalogue agents
#  open source - recommandations - prompt optionnel - Ollama local
#  TOUTES les routes API renvoient du JSON. Jamais de HTML d erreur.
# ============================================================
import json, os, re, shutil, subprocess, sys, threading, time, urllib.request
from collections import deque
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

VERSION       = "13.0"
HOST          = os.environ.get("NERCEL13_HOST", "127.0.0.1")
# 5060..5061 sont des ports non-bloques par les navigateurs ? NON :
# Chrome/Firefox bloquent 5060/5061 (range SAFECOM). 5065 (v12) marche,
# donc on prend 5067 pour la v13.
PORT          = int(os.environ.get("NERCEL13_PORT", "5067"))
ROOT          = os.path.dirname(os.path.abspath(__file__))
DATA_FILE     = os.path.join(ROOT, "nercel13_data.json")
SCAFFOLD_ROOT = os.path.join(ROOT, "scaffolds13")
OLLAMA        = os.environ.get("NERCEL13_OLLAMA", "http://127.0.0.1:11434")

# ---------------- metriques reelles (/proc) ----------------
CPU_LOCK = threading.Lock()
LAST_CPU = None

def read_cpu_ticks():
    with open("/proc/stat") as f:
        parts = f.readline().split()[1:]
    vals = [int(x) for x in parts]
    idle = vals[3] + (vals[4] if len(vals) > 4 else 0)
    return idle, sum(vals)

def cpu_percent():
    global LAST_CPU
    idle, total = read_cpu_ticks()
    with CPU_LOCK:
        if LAST_CPU is None:
            LAST_CPU = (idle, total)
            return None
        pi, pt = LAST_CPU
        LAST_CPU = (idle, total)
    di, dt = idle - pi, total - pt
    return round(100.0 * (1.0 - di / float(dt)), 1) if dt > 0 else 0.0

def mem_percent():
    d = {}
    with open("/proc/meminfo") as f:
        for line in f:
            k = line.split(":")
            if len(k) == 2:
                d[k[0]] = int(k[1].strip().split()[0])
    tot = d.get("MemTotal", 1)
    ava = d.get("MemAvailable", 0)
    return round(100.0 * (tot - ava) / float(tot), 1)

def net_bytes():
    rx = tx = 0
    with open("/proc/net/dev") as f:
        for line in f.readlines()[2:]:
            if ":" not in line:
                continue
            dev, rest = line.split(":", 1)
            if dev.strip() == "lo":
                continue
            cols = rest.split()
            rx += int(cols[0]); tx += int(cols[8])
    return rx, tx

def disk_percent():
    u = shutil.disk_usage(ROOT)
    return round(100.0 * u.used / u.total, 1)

SERIES = {"cpu": deque(maxlen=300), "mem": deque(maxlen=300),
          "rx": deque(maxlen=300), "tx": deque(maxlen=300)}
LAST_NET = None

def sampler():
    global LAST_NET
    while True:
        cpu = cpu_percent()
        rx, tx = net_bytes()
        with CPU_LOCK:
            if cpu is not None:
                SERIES["cpu"].append([int(time.time()), cpu])
            if LAST_NET is not None:
                SERIES["rx"].append([int(time.time()), rx - LAST_NET[0]])
                SERIES["tx"].append([int(time.time()), tx - LAST_NET[1]])
            LAST_NET = (rx, tx)
        SERIES["mem"].append([int(time.time()), mem_percent()])
        time.sleep(5)

# ---------------- donnees + persistance ----------------
DATA = {"agents": [], "runs": [], "scaffolds_created": []}
DATA_LOCK = threading.Lock()

def now_iso():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def safe_int(v, d=0):
    try:
        return int(v)
    except Exception:
        try:
            return int(float(v))
        except Exception:
            return d

def load_data():
    global DATA
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE) as f:
                d = json.load(f)
            if isinstance(d, dict):
                DATA = d
        except Exception as e:
            print("[warn] nercel13_data.json ignore:", e)
    DATA.setdefault("agents", [])
    DATA.setdefault("runs", [])
    DATA.setdefault("scaffolds_created", [])
    for d0 in DEFAULT_AGENTS:
        if not any(a.get("id") == d0["id"] for a in DATA["agents"]):
            DATA["agents"].append(json.loads(json.dumps(d0)))
    for a in DATA["agents"]:
        a.setdefault("interval", 0)
        a.setdefault("source", "builtin")
        a.setdefault("goal", "")
        a.setdefault("last_run", 0)
        a.setdefault("commands", [])

def save_data():
    with DATA_LOCK:
        tmp = DATA_FILE + ".tmp"
        with open(tmp, "w") as f:
            json.dump(DATA, f, ensure_ascii=False, indent=1)
        os.replace(tmp, DATA_FILE)

# ---------------- agents reels (subprocess) ----------------
DEFAULT_AGENTS = [
 {"id": "compile", "name": "Compile Check", "goal": "verifier que tout le python compile",
  "commands": ["python3 -m py_compile *.py"], "interval": 0, "source": "builtin"},
 {"id": "tests", "name": "Test Runner", "goal": "lancer les tests",
  "commands": ["python3 -m unittest discover -s tests -v"], "interval": 0, "source": "builtin"},
 {"id": "deps", "name": "Dependency Audit", "goal": "verifier les dependances",
  "commands": ["pip check || echo rien-a-signaler"], "interval": 0, "source": "builtin"},
 {"id": "docs", "name": "Docs Snapshot", "goal": "inventaire du projet",
  "commands": ["ls -la", "wc -l *.py"], "interval": 0, "source": "builtin"},
]

def run_agent(agent_id):
    ag = next((a for a in DATA["agents"] if a["id"] == agent_id), None)
    if not ag:
        return None
    rec = {"run_id": int(time.time() * 1000), "agent": agent_id,
           "agent_name": ag["name"], "started": now_iso(),
           "status": "running", "output": ""}
    with DATA_LOCK:
        DATA["runs"].insert(0, rec)
        del DATA["runs"][200:]
        ag["last_run"] = int(time.time())
    threading.Thread(target=_exec_agent, args=(ag, rec), daemon=True).start()
    save_data()
    return rec

def _exec_agent(agent, rec):
    outs, code = [], 0
    for cmd in agent.get("commands", []):
        try:
            p = subprocess.run(cmd, shell=True, cwd=ROOT,
                               capture_output=True, text=True, timeout=120)
            code = p.returncode
            outs.append("$ " + cmd + "\n" + (p.stdout or "") + (p.stderr or ""))
        except subprocess.TimeoutExpired:
            code = 124
            outs.append("$ " + cmd + "\nTIMEOUT (120s)")
        except Exception as e:
            code = 1
            outs.append("$ " + cmd + "\nERREUR: " + str(e))
        if len(outs[-1]) > 4000:
            outs[-1] = outs[-1][:4000] + "\n...[tronque]"
        if code != 0:
            break
    rec["status"] = "ok" if code == 0 else "fail"
    rec["exit"] = code
    rec["output"] = "\n".join(outs)
    with DATA_LOCK:
        pass
    save_data()

# ---------------- scheduler (agents auto) ----------------
def scheduler():
    while True:
        time.sleep(10)
        n = int(time.time())
        for ag in list(DATA["agents"]):
            iv = ag.get("interval") or 0
            if iv > 0 and n - (ag.get("last_run") or 0) >= iv:
                run_agent(ag["id"])

# ---------------- blueprints locaux ----------------
BLUEPRINTS = [
 {"id": "tester", "name": "Test Runner", "tags": ["test", "unittest", "pytest", "qualite"],
  "desc": "Compile le projet puis lance les tests.",
  "commands": ["python3 -m py_compile *.py",
               "python3 -m unittest discover -s tests -v"]},
 {"id": "watcher", "name": "File Watcher", "tags": ["fichier", "surveille", "watch", "change", "git"],
  "desc": "Git status + fichiers python modifies recemment.",
  "commands": ["git status --short || true",
               "find . -name '*.py' -newermt '1 hour ago' | head -20"]},
 {"id": "deployer", "name": "Deploy Check", "tags": ["deploy", "lancer", "service", "port", "processus"],
  "desc": "Ports en ecoute + processus python vivants.",
  "commands": ["ss -tln | head -20",
               "ps aux | grep python | grep -v grep | head -10"]},
 {"id": "doc-writer", "name": "Docs Snapshot", "tags": ["doc", "readme", "documentation", "inventaire"],
  "desc": "Inventaire des fichiers + stats lignes.",
  "commands": ["ls -la", "wc -l *.py"]},
 {"id": "security", "name": "Security Scan", "tags": ["securite", "security", "scan", "secret", "cle"],
  "desc": "Cherche secrets/cles oublies + permissions larges.",
  "commands": ["grep -rn --include='*.py' --include='*.js' -iE 'password|secret|token|api[_-]?key' . | grep -v '.pyc' | head -20 || true",
               "find . -type f -perm -o+w | head -10"]},
 {"id": "backup", "name": "Backup Bot", "tags": ["sauvegarde", "backup", "archive", "tar"],
  "desc": "Archive le code dans un tar date.",
  "commands": ["tar -czf backup_$(date +%F_%H%M).tgz *.py *.json *.sh 2>/dev/null || tar -czf backup_$(date +%F_%H%M).tgz *.py",
               "ls -la backup_*.tgz | tail -3"]},
 {"id": "cleaner", "name": "Cache Cleaner", "tags": ["nettoie", "clean", "cache", "pyc", "espace"],
  "desc": "Supprime les .pyc et mesure la taille du projet.",
  "commands": ["find . -name '*.pyc' -delete", "du -sh . 2>/dev/null"]},
 {"id": "api-monitor", "name": "API Monitor", "tags": ["api", "monitor", "curl", "sante", "health"],
  "desc": "Sonde la sante des services locaux (v12 + v13).",
  "commands": ["curl -s -m 3 http://127.0.0.1:5067/api/health || echo v13-down",
               "curl -s -m 3 http://127.0.0.1:5065/api/health || echo v12-down"]},
]

# ---------------- catalogue agents open source (vrais repos) ----------------
OSS_CATALOG = [
 {"id": "aider", "name": "Aider", "repo": "https://github.com/Aider-AI/aider", "lang": "Python",
  "category": "pair-programming", "install": "pip install aider-chat",
  "desc": "AI pair programming dans le terminal: edite le code et git-commit tout seul.",
  "tags": ["code", "edition", "terminal", "git", "assistant"]},
 {"id": "openhands", "name": "OpenHands", "repo": "https://github.com/All-Hands-AI/OpenHands", "lang": "Python",
  "category": "autonomous-dev", "install": "docker run -p 3000:3000 all-hands-ai/openhands",
  "desc": "AI software engineer autonome (ex-OpenDevin): ecrit du code, lance des tests, ouvre des PR.",
  "tags": ["autonome", "dev", "pr", "tests", "agent"]},
 {"id": "open-interpreter", "name": "Open Interpreter", "repo": "https://github.com/OpenInterpreter/open-interpreter", "lang": "Python",
  "category": "code-execution", "install": "pip install open-interpreter",
  "desc": "Laisse le LLM executer du code sur ta machine: python, js, shell.",
  "tags": ["shell", "execution", "terminal", "code"]},
 {"id": "crewai", "name": "CrewAI", "repo": "https://github.com/crewAIInc/crewAI", "lang": "Python",
  "category": "multi-agent", "install": "pip install crewai",
  "desc": "Orchestre des agents autonomes par roles (chercheur, redacteur, reviewer...).",
  "tags": ["multi-agent", "orchestration", "equipe", "workflow"]},
 {"id": "autogen", "name": "AutoGen", "repo": "https://github.com/microsoft/autogen", "lang": "Python",
  "category": "multi-agent", "install": "pip install pyautogen",
  "desc": "Framework Microsoft pour conversations multi-agents qui resolvent des taches.",
  "tags": ["multi-agent", "microsoft", "conversation", "taches"]},
 {"id": "langgraph", "name": "LangGraph", "repo": "https://github.com/langchain-ai/langgraph", "lang": "Python",
  "category": "agent-graph", "install": "pip install langgraph",
  "desc": "Graphes d agents avec etat, au dessus de LangChain.",
  "tags": ["graphe", "workflow", "etat", "langchain"]},
 {"id": "gpt-engineer", "name": "gpt-engineer", "repo": "https://github.com/AntonOsika/gpt-engineer", "lang": "Python",
  "category": "codegen", "install": "pip install gpt-engineer",
  "desc": "Tu specifies, il genere un codebase entier.",
  "tags": ["generation", "codebase", "scaffold", "prompt"]},
 {"id": "swe-agent", "name": "SWE-agent", "repo": "https://github.com/princeton-nlp/SWE-agent", "lang": "Python",
  "category": "issue-fixing", "install": "pip install sweagent",
  "desc": "Agent autonome qui repare de vraies issues GitHub.",
  "tags": ["github", "issues", "bug", "fix"]},
 {"id": "continue", "name": "Continue", "repo": "https://github.com/continuedev/continue", "lang": "TypeScript",
  "category": "ide-assistant", "install": "plugin VS Code / JetBrains, open source",
  "desc": "Assistant de code open source dans ton IDE (autocomplete, chat, refactor).",
  "tags": ["ide", "vscode", "autocomplete", "assistant"]},
 {"id": "devika", "name": "Devika", "repo": "https://github.com/stitionai/devika", "lang": "Python",
  "category": "autonomous-dev", "install": "git clone + pip install -r requirements.txt",
  "desc": "AI software engineer open source: planifie, cherche, code.",
  "tags": ["autonome", "planification", "dev", "recherche"]},
 {"id": "flowise", "name": "Flowise", "repo": "https://github.com/FlowiseAI/Flowise", "lang": "TypeScript",
  "category": "visual-builder", "install": "npm i -g flowise && npx flowise start",
  "desc": "Interface drag and drop pour construire des agents LLM et des flows.",
  "scaffold_hint": True,
  "tags": ["visuel", "no-code", "workflow", "ui"]},
 {"id": "dify", "name": "Dify", "repo": "https://github.com/langgenius/dify", "lang": "Python",
  "category": "llm-platform", "install": "docker compose up (repo officiel)",
  "desc": "Plateforme LLM open source: agents, RAG, workflows.",
  "tags": ["plateforme", "rag", "workflow", "api"]},
]

# ---------------- recommandation (100% stdlib, deterministe) ----------------
STOP = set(("le la les de des du un une et ou pour avec dans sur mon ma mes ton ta tes "
            "je tu il elle nous vous ils qui que quoi comment faire fais veut voudrais "
            "creer agent code projet the and for with from this that you your are").split())

def tokens(s):
    return [w for w in re.findall(r"[a-z0-9]{3,}", (s or "").lower()) if w not in STOP]

def score_entry(entry, toks):
    tags = [t.lower() for t in entry.get("tags", [])]
    hay = (entry.get("desc", "") + " " + entry.get("name", "")).lower()
    score, matched = 0, []
    for t in toks:
        if t in tags:
            score += 4; matched.append(t)
        elif t in hay:
            score += 1; matched.append(t)
    return score, sorted(set(matched))

def recommend(goal):
    toks = tokens(goal)
    if not toks:
        return {"goal": goal, "blueprints": [], "oss": [],
                "note": "donne plus de mots-cles"}
    sb = []
    for b in BLUEPRINTS:
        s, m = score_entry(b, toks)
        sb.append({"id": b["id"], "name": b["name"], "desc": b["desc"], "score": s, "matched": m})
    so = []
    for o in OSS_CATALOG:
        s, m = score_entry(o, toks)
        so.append({"id": o["id"], "name": o["name"], "repo": o["repo"], "desc": o["desc"],
                   "install": o["install"], "score": s, "matched": m})
    sb.sort(key=lambda x: -x["score"])
    so.sort(key=lambda x: -x["score"])
    return {"goal": goal, "keywords": toks,
            "blueprints": [b for b in sb if b["score"] > 0][:3],
            "oss": [o for o in so if o["score"] > 0][:3]}

# ---------------- prompt optionnel -> commandes (repli sans Ollama) ----------------
PROMPT_RULES = [
 (("test", "teste", "tester", "unittest", "pytest"),
  ["python3 -m py_compile *.py", "python3 -m unittest discover -s tests -v"]),
 (("compile", "compil", "syntaxe"), ["python3 -m py_compile *.py"]),
 (("dependance", "deps", "pip", "package", "requirement"), ["pip check || echo rien-a-signaler"]),
 (("git", "commit", "branche", "repo"),
  ["git status --short || true", "git log --oneline -5 || true"]),
 (("doc", "readme", "documentation"), ["ls -la", "wc -l *.py"]),
 (("disque", "disk", "espace"), ["df -h", "du -sh * 2>/dev/null | sort -rh | head -10"]),
 (("port", "reseau", "net", "listen"), ["ss -tln | head -20"]),
 (("sauvegarde", "backup", "archive"),
  ["tar -czf backup_$(date +%F_%H%M).tgz *.py *.json 2>/dev/null || tar -czf backup_$(date +%F_%H%M).tgz *.py"]),
 (("cache", "nettoie", "clean", "pyc"), ["find . -name '*.pyc' -delete", "du -sh . 2>/dev/null"]),
 (("surveille", "watch", "fichier", "change"),
  ["find . -name '*.py' -newermt '1 hour ago' | head -20"]),
 (("securite", "secret", "token", "key"),
  ["grep -rn -iE 'password|secret|token|api[_-]?key' --include='*.py' . | head -20 || true"]),
]

def compile_prompt(text):
    low = (text or "").lower()
    cmds = []
    for keys, c in PROMPT_RULES:
        if any(k in low for k in keys):
            cmds.extend(c)
    if not cmds:
        safe = re.sub(r'["`$;|&><]', "", text)[:120]
        cmds = ['echo "objectif: ' + safe + '"']
    cmds.append("echo '[agent] done'")
    return cmds

# ---------------- bridge Ollama (open source, local) ----------------
FORBIDDEN = ("sudo", "rm -rf /", "mkfs", "dd if=", "> /dev/sd", "shutdown", "reboot",
             ":(){", "chmod -R 777 /")

def is_safe_command(c):
    low = c.lower()
    return not any(b in low for b in FORBIDDEN)

def ollama_status():
    try:
        with urllib.request.urlopen(OLLAMA + "/api/tags", timeout=2) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
        return True, [m.get("name", "?") for m in data.get("models", [])]
    except Exception:
        return False, []

def ollama_commands(prompt):
    ok, models = ollama_status()
    if not ok or not models:
        return None
    sysmsg = ("Tu es un generateur de commandes shell. Repond UNIQUEMENT avec des lignes "
              "de commande, une par ligne, chaque ligne commence par '$ '. "
              "Aucune explication. Objectif: ")
    body = json.dumps({"model": models[0], "prompt": sysmsg + prompt,
                       "stream": False}).encode("utf-8")
    req = urllib.request.Request(OLLAMA + "/api/generate", data=body,
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            txt = json.loads(r.read().decode("utf-8", "replace")).get("response", "")
    except Exception:
        return None
    cmds = []
    for line in txt.splitlines():
        line = line.strip()
        if line.startswith("$"):
            c = line[1:].strip()
            if c and is_safe_command(c):
                cmds.append(c)
    if not cmds:
        return None
    return cmds, models[0]

def build_commands(p):
    prompt = (p.get("prompt") or "").strip()
    goal = (p.get("goal") or "").strip()
    bp = p.get("blueprint") or ""
    if bp:
        b = next((b for b in BLUEPRINTS if b["id"] == bp), None)
        if b:
            return list(b["commands"]), "blueprint:" + bp
    if p.get("use_ollama"):
        r = ollama_commands(prompt or goal)
        if r:
            return r[0], "ollama:" + r[1]
    text = prompt or goal
    if text:
        return compile_prompt(text), "prompt-rules"
    raise ValueError("donne au moins un objectif, un prompt ou un blueprint")

# ---------------- CRUD agents ----------------
def slugify(s):
    s = re.sub(r"[^a-z0-9_-]+", "-", (s or "").lower()).strip("-")
    return s or "agent"

def py_ident(s):
    # identifiant python valide pour les noms de packages/modules (py-lib)
    s = re.sub(r"[^a-z0-9_]+", "_", (s or "").lower()).strip("_")
    if not s or s[0].isdigit():
        s = "p_" + s
    return s or "pkg"

def agent_create(p):
    name = (p.get("name") or "").strip()
    if not name:
        raise ValueError("champ name requis")
    aid = slugify(name)
    base, i = aid, 2
    while any(a["id"] == aid for a in DATA["agents"]):
        aid = base + "-" + str(i); i += 1
    cmds, source = build_commands(p)
    ag = {"id": aid, "name": name, "goal": (p.get("goal") or "").strip(),
          "commands": cmds, "source": source,
          "interval": safe_int(p.get("interval")),
          "created": now_iso(), "last_run": 0}
    with DATA_LOCK:
        DATA["agents"].append(ag)
    save_data()
    return {"ok": True, "agent": ag}

def update_agent(ag, p):
    if p.get("name"):
        ag["name"] = str(p["name"]).strip()
    if "goal" in p:
        ag["goal"] = str(p.get("goal") or "").strip()
    if "interval" in p:
        ag["interval"] = safe_int(p.get("interval"))
    if p.get("commands"):
        ag["commands"] = [str(c) for c in p["commands"]][:20]
        ag["source"] = "manuel"
    elif any(k in p for k in ("prompt", "blueprint", "use_ollama")):
        cmds, src = build_commands(p)
        ag["commands"] = cmds
        ag["source"] = src

# ---------------- scaffolds reels (fichiers sur disque) ----------------
SCAFFOLD_TEMPLATES = {
 "py-cli": {
  "name": "Python CLI",
  "desc": "Outil ligne de commande 100% stdlib (argparse) + test unittest.",
  "files": [
   ["cli.py", '''#!/usr/bin/env python3
"""CLI genere par Nercel 13 - projet {NAME}."""
import argparse

def main():
    ap = argparse.ArgumentParser(prog="{NAME}")
    ap.add_argument("who", nargs="?", default="world")
    ap.add_argument("--shout", action="store_true")
    a = ap.parse_args()
    msg = "Hello, " + a.who + "!"
    print(msg.upper() if a.shout else msg)

if __name__ == "__main__":
    main()
'''],
   ["tests/test_cli.py", '''import os, sys, unittest, subprocess

HERE = os.path.dirname(os.path.abspath(__file__))
CLI = os.path.join(HERE, "..", "cli.py")

class TestCli(unittest.TestCase):
    def test_runs(self):
        r = subprocess.run([sys.executable, CLI, "ok"], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0)
        self.assertIn("Hello, ok", r.stdout)

if __name__ == "__main__":
    unittest.main()
'''],
   ["README.md", "# {NAME}\n\nGenere par Nercel 13 le {DATE}.\n\n    python3 cli.py ForgeHub --shout\n    python3 -m unittest discover -s tests -v\n"],
  ],
 },
 "py-lib": {
  "name": "Python Library",
  "desc": "Petite lib python importable + tests unittest.",
  "files": [
   ["{NAME}/__init__.py", '''__version__ = "0.1.0"

def add(a, b):
    return a + b

def slugify(s):
    out = []
    for c in s.lower():
        out.append(c if c.isalnum() else "-")
    return "".join(out).strip("-")
'''],
   ["tests/test_core.py", '''import os, sys, unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import {NAME}

class TestCore(unittest.TestCase):
    def test_add(self):
        self.assertEqual({NAME}.add(2, 3), 5)

    def test_slugify(self):
        self.assertEqual({NAME}.slugify("Forge Hub 13"), "forge-hub-13")

if __name__ == "__main__":
    unittest.main()
'''],
   ["README.md", "# {NAME} (lib)\n\nGenere le {DATE}.\n\n    python3 -m unittest discover -s tests -v\n"],
  ],
 },
 "http-service": {
  "name": "Micro-service JSON",
  "desc": "API JSON sans aucune dependance, demarre direct, /health inclus.",
  "files": [
   ["service.py", '''#!/usr/bin/env python3
"""Micro-service JSON 100% stdlib - projet {NAME}. Lance: python3 service.py"""
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ITEMS = [{"id": 1, "name": "demo"}]

class H(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/health":
            return self.reply({"ok": True, "service": "{NAME}"})
        if self.path == "/api/items":
            return self.reply({"items": ITEMS})
        self.reply({"error": "not found", "path": self.path}, 404)

    def reply(self, obj, code=200):
        b = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def log_message(self, *a):
        pass

if __name__ == "__main__":
    print("{NAME} service sur http://127.0.0.1:5070")
    ThreadingHTTPServer(("127.0.0.1", 5070), H).serve_forever()
'''],
   ["README.md", "# {NAME}\n\n    python3 service.py\n    curl http://127.0.0.1:5070/health\n"],
  ],
 },
 "flask-api": {
  "name": "Flask API",
  "desc": "API REST Flask classique (necessite pip install flask).",
  "files": [
   ["app.py", '''from flask import Flask, jsonify

app = Flask(__name__)

@app.route("/")
def home():
    return jsonify(ok=True, app="{NAME}")

@app.route("/api/items")
def items():
    return jsonify(items=[{"id": 1, "name": "demo"}])

if __name__ == "__main__":
    app.run(port=5071, debug=True)
'''],
   ["requirements.txt", "flask>=3.0\n"],
   ["README.md", "# {NAME}\n\n    pip install -r requirements.txt\n    python3 app.py\n"],
  ],
 },
 "fastapi-api": {
  "name": "FastAPI API",
  "desc": "API FastAPI moderne + docs auto sur /docs.",
  "files": [
   ["main.py", '''from fastapi import FastAPI

app = FastAPI(title="{NAME}")

@app.get("/health")
def health():
    return {"ok": True}

@app.get("/api/items")
def items():
    return [{"id": 1, "name": "demo"}]
'''],
   ["requirements.txt", "fastapi>=0.110\nuvicorn>=0.29\n"],
   ["README.md", "# {NAME}\n\n    pip install -r requirements.txt\n    uvicorn main:app --port 5072\n"],
  ],
 },
 "static-site": {
  "name": "Static Site",
  "desc": "Site web html/css/js pur, ouvre index.html et c est parti.",
  "files": [
   ["index.html", '''<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{NAME}</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<h1>{NAME}</h1>
<p>Genere par Nercel 13.</p>
<button id="b">Clique</button>
<span id="c">0</span>
<script src="app.js"></script>
</body>
</html>
'''],
   ["style.css", '''* { box-sizing: border-box; margin: 0; padding: 0; }
body { background: #0d0e12; color: #d7d9de; font: 16px system-ui, sans-serif;
       display: flex; flex-direction: column; gap: 14px;
       align-items: center; justify-content: center; min-height: 100vh; }
h1 { color: #ff7a1a; letter-spacing: 2px; }
button { background: #ff7a1a; color: #141414; border: 0; padding: 10px 22px;
         border-radius: 8px; font-weight: 600; cursor: pointer; }
'''],
   ["app.js", '''let n = 0;
document.getElementById("b").addEventListener("click", () => {
  n += 1;
  document.getElementById("c").textContent = n;
});
'''],
  ],
 },
 "agent-bot": {
  "name": "Agent Bot",
  "desc": "Agent autonome minimal: boucle sur tasks.json, 100% stdlib.",
  "files": [
   ["bot.py", '''#!/usr/bin/env python3
"""Agent autonome minimal - projet {NAME}. Lance: python3 bot.py"""
import json, os, subprocess, time

HERE = os.path.dirname(os.path.abspath(__file__))
TASKS = os.path.join(HERE, "tasks.json")

def load_tasks():
    if os.path.exists(TASKS):
        with open(TASKS) as f:
            return json.load(f)
    return [{"cmd": "echo pas-de-tasks-json", "interval": 60}]

def main():
    print("[bot] demarre")
    last = {}
    while True:
        for i, t in enumerate(load_tasks()):
            iv = t.get("interval", 60)
            if time.time() - last.get(i, 0) < iv:
                continue
            last[i] = time.time()
            r = subprocess.run(t["cmd"], shell=True, capture_output=True, text=True)
            print("[bot] $", t["cmd"], "->", r.returncode)
        time.sleep(5)

if __name__ == "__main__":
    main()
'''],
   ["tasks.json", '[{"cmd": "ls -la", "interval": 30}]\n'],
  ],
 },
 "data-pipeline": {
  "name": "Data Pipeline",
  "desc": "Convertisseur CSV vers JSON, 100% stdlib.",
  "files": [
   ["pipeline.py", '''#!/usr/bin/env python3
"""CSV -> JSON - projet {NAME}. Lance: python3 pipeline.py data.csv [out.json]"""
import csv, json, sys

def convert(src, dst):
    with open(src, newline="") as f:
        rows = list(csv.DictReader(f))
    with open(dst, "w") as f:
        json.dump(rows, f, ensure_ascii=False, indent=1)
    print("OK:", len(rows), "lignes ->", dst)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit("usage: python3 pipeline.py data.csv [out.json]")
    convert(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else sys.argv[1] + ".json")
'''],
   ["README.md", "# {NAME}\n\n    python3 pipeline.py data.csv\n"],
  ],
 },
}

def scaffold_templates_public():
    return [{"id": k, "name": v["name"], "desc": v["desc"], "files": len(v["files"])}
            for k, v in SCAFFOLD_TEMPLATES.items()]

def scaffold_create(p):
    tpl_id = p.get("tpl") or ""
    name = slugify(p.get("name") or "")
    if not name:
        raise ValueError("nom de projet requis (a-z 0-9 tirets)")
    tpl = SCAFFOLD_TEMPLATES.get(tpl_id)
    if not tpl:
        raise ValueError("template inconnu: " + tpl_id)
    target = os.path.join(SCAFFOLD_ROOT, name)
    if os.path.exists(target):
        raise ValueError("le projet existe deja: scaffolds13/" + name)
    made = []
    # FIX v13.1: {NAME} dans les chemins + identifiant python valide (import)
    for rel, content in tpl["files"]:
        rel = rel.replace("{NAME}", py_ident(name))
        fp = os.path.join(target, rel)
        os.makedirs(os.path.dirname(fp), exist_ok=True)
        with open(fp, "w") as f:
            f.write(content.replace("{NAME}", py_ident(name)).replace("{DATE}", now_iso()))
        made.append("scaffolds13/" + name + "/" + rel)
    rec = {"tpl": tpl_id, "name": name, "created": now_iso(), "files": made}
    with DATA_LOCK:
        DATA["scaffolds_created"].insert(0, rec)
        del DATA["scaffolds_created"][100:]
    save_data()
    return {"ok": True, "dir": "scaffolds13/" + name, "files": made}

# ---------------- etat global ----------------
def state():
    cpu = list(SERIES["cpu"])[-120:]
    mem = list(SERIES["mem"])[-120:]
    rx = list(SERIES["rx"])[-120:]
    tx = list(SERIES["tx"])[-120:]
    la = os.getloadavg()
    return {
        "ts": now_iso(), "version": VERSION,
        "metrics": {
            "cpu": cpu[-1][1] if cpu else None,
            "mem": mem[-1][1] if mem else None,
            "rx": rx[-1][1] if rx else 0,
            "tx": tx[-1][1] if tx else 0,
            "disk": disk_percent(),
            "load": round(max(la), 2),
        },
        "series": {"cpu": cpu, "mem": mem, "rx": rx, "tx": tx},
        "agents": DATA["agents"],
        "runs": DATA["runs"][:50],
        "scaffolds": scaffold_templates_public(),
        "scaffolds_created": DATA["scaffolds_created"],
    }

# ---------------- page (dashboard Grafana-style) ----------------
PAGE = r"""<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Nercel 13 FORGE</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0d0e12;color:#d7d9de;font:14px/1.45 system-ui,Segoe UI,Roboto,sans-serif}
header{display:flex;align-items:center;gap:14px;padding:10px 18px;background:#14161c;border-bottom:1px solid #23252c;flex-wrap:wrap}
.brand{font-size:18px;letter-spacing:2px;color:#f2f3f5}
.brand b{color:#ff7a1a}
.ver{color:#8a8f98;font-size:12px}
#clock{margin-left:auto;color:#8a8f98;font-family:monospace}
.cards{display:flex;gap:10px;padding:14px 18px;flex-wrap:wrap}
.card{background:#17181d;border:1px solid #23252c;border-radius:8px;padding:10px 14px;min-width:120px;flex:1}
.card .k{color:#8a8f98;font-size:11px;text-transform:uppercase;letter-spacing:1px}
.card .v{font-size:22px;font-family:monospace;margin:4px 0;color:#f2f3f5}
.bar{height:4px;background:#23252c;border-radius:2px;overflow:hidden}
.bar i{display:block;height:100%;background:#ff7a1a;width:0%}
.charts{display:flex;gap:12px;padding:0 18px 14px;flex-wrap:wrap}
.panel{background:#17181d;border:1px solid #23252c;border-radius:8px;padding:10px 12px;flex:1;min-width:320px}
.panel h3{font-size:12px;color:#8a8f98;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px}
canvas{width:100%;height:150px;display:block}
.tabs{display:flex;gap:8px;padding:0 18px 10px;align-items:center;flex-wrap:wrap}
.tab{background:#17181d;border:1px solid #23252c;color:#d7d9de;padding:6px 14px;border-radius:6px;cursor:pointer}
.tab.on{border-color:#ff7a1a;color:#ff7a1a}
.btn{background:#17181d;border:1px solid #23252c;color:#d7d9de;padding:6px 14px;border-radius:6px;cursor:pointer}
.btn.primary{background:#ff7a1a;border-color:#ff7a1a;color:#141414;font-weight:600}
main{padding:0 18px 30px}
.tabbody{display:none}.tabbody.on{display:block}
h3.sec{margin:14px 0 8px;color:#8a8f98;font-size:12px;text-transform:uppercase;letter-spacing:1px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:10px}
.agent,.cat{background:#17181d;border:1px solid #23252c;border-radius:8px;padding:12px}
.ahead{display:flex;align-items:center;gap:8px;margin-bottom:6px;flex-wrap:wrap}
.ahead a{color:#4fc3f7;text-decoration:none}
.src{margin-left:auto;color:#8a8f98;font-size:11px}
.agoal{color:#aeb2ba;font-size:12px;margin-bottom:8px}
.ameta{color:#8a8f98;font-size:11px;margin-bottom:8px}
.ameta code{background:#0d0e12;padding:1px 4px;border-radius:3px}
.arow{display:flex;gap:6px;flex-wrap:wrap}
.arow button,.chip{background:#1d1f26;border:1px solid #2a2d35;color:#d7d9de;padding:4px 10px;border-radius:5px;cursor:pointer;font-size:12px}
.chip{text-decoration:none;display:inline-block;margin:2px}
.chip.oss{color:#4fc3f7;border-color:#1e3a4a}
.dot{width:9px;height:9px;border-radius:50%;display:inline-block}
.dot.ok{background:#3fb950}.dot.bad{background:#e5534b}.dot.run{background:#d29922}.dot.idle{background:#3d444d}
.recot{color:#8a8f98;font-size:12px;margin:8px 0 4px}
.run{background:#17181d;border:1px solid #23252c;border-radius:8px;margin-bottom:8px;padding:10px}
.rhead{cursor:pointer;font-family:monospace;font-size:12px}
.rout{margin-top:8px;background:#0d0e12;border:1px solid #23252c;padding:8px;max-height:220px;overflow:auto;font-size:11px;white-space:pre-wrap;color:#9ecbff}
.hide{display:none}
.made{font-family:monospace;font-size:12px;color:#aeb2ba;padding:6px 10px;background:#17181d;border:1px solid #23252c;border-radius:6px;margin-bottom:6px}
#modal-bg{position:fixed;inset:0;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;z-index:50}
#modal{background:#17181d;border:1px solid #2a2d35;border-radius:10px;padding:18px;width:min(520px,92vw);max-height:88vh;overflow:auto}
#modal label{display:block;margin:10px 0;font-size:12px;color:#aeb2ba}
#modal input,#modal textarea,#modal select{width:100%;margin-top:4px;background:#0d0e12;border:1px solid #2a2d35;color:#d7d9de;border-radius:6px;padding:7px 9px;font:inherit}
#modal .chk input{width:auto}
#modal .row{display:flex;gap:8px;margin-top:12px;flex-wrap:wrap}
.hidden{display:none!important}
#toasts{position:fixed;right:14px;bottom:14px;z-index:60}
.toast{background:#1d2b21;border:1px solid #3fb950;color:#c9f0d0;padding:8px 12px;border-radius:6px;margin-top:6px;font-size:13px}
.toast.bad{background:#2b1d1d;border-color:#e5534b;color:#f0c9c9}
#reco{margin-top:6px}
</style>
</head>
<body>
<header>
  <div class="brand">NERCEL <b>13</b> FORGE</div>
  <div class="ver">v13.0 · port 5067 · metriques reels · agents reels · JSON garanti</div>
  <div id="clock"></div>
</header>

<section class="cards">
  <div class="card"><div class="k">CPU</div><div class="v" id="m-cpu">--</div><div class="bar"><i id="b-cpu"></i></div></div>
  <div class="card"><div class="k">RAM</div><div class="v" id="m-mem">--</div><div class="bar"><i id="b-mem"></i></div></div>
  <div class="card"><div class="k">NET ↓ o/5s</div><div class="v" id="m-rx">--</div></div>
  <div class="card"><div class="k">NET ↑ o/5s</div><div class="v" id="m-tx">--</div></div>
  <div class="card"><div class="k">DISK</div><div class="v" id="m-disk">--</div><div class="bar"><i id="b-disk"></i></div></div>
  <div class="card"><div class="k">LOAD</div><div class="v" id="m-load">--</div></div>
</section>

<section class="charts">
  <div class="panel"><h3>CPU / RAM %</h3><canvas id="ch1" width="560" height="150"></canvas></div>
  <div class="panel"><h3>Reseau ↓↑ octets/5s</h3><canvas id="ch2" width="560" height="150"></canvas></div>
</section>

<nav class="tabs">
  <button class="tab on" data-t="agents">Agents</button>
  <button class="tab" data-t="scaffolds">Scaffolds</button>
  <button class="tab" data-t="catalog">Catalogue OSS</button>
  <button class="tab" data-t="runs">Executions</button>
  <button class="btn primary" id="new-agent">+ Agent personnalise</button>
</nav>

<main>
  <section id="tab-agents" class="tabbody on"><div id="agent-grid" class="grid"></div></section>
  <section id="tab-scaffolds" class="tabbody">
    <h3 class="sec">Modeles de scaffolds (generation reelle de fichiers)</h3>
    <div id="tpl-grid" class="grid"></div>
    <h3 class="sec">Projets generes</h3>
    <div id="made-list"></div>
  </section>
  <section id="tab-catalog" class="tabbody">
    <h3 class="sec">Agents open source (vrais repos GitHub)</h3>
    <div id="cat-list" class="grid"></div>
    <h3 class="sec">Blueprints locaux (bases d agents pretes)</h3>
    <div id="bp-list" class="grid"></div>
  </section>
  <section id="tab-runs" class="tabbody"><div id="run-list"></div></section>
</main>

<div id="modal-bg" class="hidden">
  <div id="modal">
    <h3 id="modal-title">Agent personnalise</h3>
    <label>Nom<input id="f-name" placeholder="night-tester"></label>
    <label>Objectif<input id="f-goal" placeholder="teste mon code et surveille les deps"></label>
    <label>Prompt (optionnel)<textarea id="f-prompt" rows="3" placeholder="instructions libres - laisse vide pour auto"></textarea></label>
    <label>Blueprint<select id="f-bp"></select></label>
    <label>Intervalle auto en secondes (0 = off)<input id="f-iv" type="number" value="0"></label>
    <label class="chk"><input id="f-ollama" type="checkbox"> Utiliser Ollama local (agent open source)</label>
    <div id="ollama-hint" class="recot"></div>
    <div class="row">
      <button class="btn" id="btn-reco">Recommander</button>
      <button class="btn primary" id="btn-save">Creer</button>
      <button class="btn" id="btn-close">Fermer</button>
    </div>
    <div id="reco"></div>
  </div>
</div>
<div id="toasts"></div>

<script>
const $ = s => document.querySelector(s);
const esc = s => (s + "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const POST = body => ({method: "POST", headers: {"Content-Type": "application/json"},
                       body: JSON.stringify(body || {})});

async function api(path, opts){
  let r;
  try { r = await fetch(path, opts || {}); }
  catch(e){ throw new Error("service injoignable: " + path); }
  let txt = "", j = null;
  try { txt = await r.text(); j = JSON.parse(txt); }
  catch(e){ throw new Error("HTTP " + r.status + " reponse non-JSON: " + txt.slice(0, 120)); }
  if(!r.ok) throw new Error(j.error || ("HTTP " + r.status));
  return j;
}

function toast(msg, bad){
  const t = document.createElement("div");
  t.className = "toast" + (bad ? " bad" : "");
  t.textContent = msg;
  $("#toasts").appendChild(t);
  setTimeout(() => t.remove(), 4200);
}

let STATE = null;
let CATALOG = {oss: [], blueprints: []};
let EDIT_ID = null;

function SER(k){ return (STATE && STATE.series && STATE.series[k]) || []; }

function fmtB(n){
  if(n === undefined || n === null) return "--";
  if(n > 1048576) return (n / 1048576).toFixed(1) + "M";
  if(n > 1024) return (n / 1024).toFixed(1) + "K";
  return "" + Math.round(n);
}

function renderCards(){
  const m = (STATE && STATE.metrics) || {};
  $("#m-cpu").textContent = m.cpu == null ? "--" : m.cpu + " %";
  $("#m-mem").textContent = m.mem == null ? "--" : m.mem + " %";
  $("#m-rx").textContent = fmtB(m.rx);
  $("#m-tx").textContent = fmtB(m.tx);
  $("#m-disk").textContent = m.disk == null ? "--" : m.disk + " %";
  $("#m-load").textContent = m.load == null ? "--" : "" + m.load;
  $("#b-cpu").style.width = Math.min(100, m.cpu || 0) + "%";
  $("#b-mem").style.width = Math.min(100, m.mem || 0) + "%";
  $("#b-disk").style.width = Math.min(100, m.disk || 0) + "%";
}

function draw(cv, series, colors, fixedMax){
  if(!cv) return;
  const ctx = cv.getContext("2d");
  const W = cv.width, H = cv.height;
  ctx.clearRect(0, 0, W, H);
  ctx.fillStyle = "#111318"; ctx.fillRect(0, 0, W, H);
  ctx.strokeStyle = "#23252c"; ctx.lineWidth = 1;
  for(let i = 1; i < 4; i++){
    const y = H * i / 4;
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
  }
  let max = fixedMax || 0;
  if(!fixedMax){
    series.forEach(s => s.forEach(p => { if(p[1] > max) max = p[1]; }));
    max = max <= 0 ? 1 : max * 1.2;
  }
  series.forEach((s, si) => {
    if(!s.length) return;
    ctx.strokeStyle = colors[si]; ctx.lineWidth = 2; ctx.beginPath();
    s.forEach((p, i) => {
      const x = (s.length === 1 ? 0 : i / (s.length - 1)) * W;
      const y = H - 4 - (p[1] / max) * (H - 10);
      if(i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    });
    ctx.stroke();
  });
  ctx.fillStyle = "#8a8f98"; ctx.font = "11px monospace";
  ctx.fillText("max " + (max >= 100 ? Math.round(max) : Math.round(max * 10) / 10), 6, 14);
}

function renderAgents(){
  const as = (STATE && STATE.agents) || [];
  const runs = (STATE && STATE.runs) || [];
  $("#agent-grid").innerHTML = as.map(a => {
    const last = runs.find(r => r.agent === a.id);
    const st = !last ? "idle" : (last.status === "ok" ? "ok" : (last.status === "fail" ? "bad" : "run"));
    return '<div class="agent">'
      + '<div class="ahead"><span class="dot ' + st + '"></span><b>' + esc(a.name) + '</b>'
      + '<span class="src">' + esc(a.source || "") + '</span></div>'
      + '<div class="agoal">' + esc(a.goal || "") + '</div>'
      + '<div class="ameta">' + (a.commands || []).length + ' cmd · auto ' + (a.interval || 0) + 's</div>'
      + '<div class="arow">'
      + '<button onclick="runAgent(\'' + a.id + '\')">Run</button>'
      + '<button onclick="editAgent(\'' + a.id + '\')">Edit</button>'
      + '<button class="danger" onclick="delAgent(\'' + a.id + '\')">Del</button>'
      + '</div></div>';
  }).join("");
}

function renderTpls(){
  const ts = (STATE && STATE.scaffolds) || [];
  $("#tpl-grid").innerHTML = ts.map(t =>
    '<div class="agent"><div class="ahead"><b>' + esc(t.name) + '</b>'
    + '<span class="src">' + t.files + ' fichiers</span></div>'
    + '<div class="agoal">' + esc(t.desc) + '</div>'
    + '<div class="arow"><button onclick="genTpl(\'' + t.id + '\')">Generer</button></div></div>'
  ).join("");
}

function renderMade(){
  const ms = (STATE && STATE.scaffolds_created) || [];
  $("#made-list").innerHTML = ms.length ? ms.map(m =>
    '<div class="made">' + esc(m.created) + ' · ' + esc(m.name) + ' (' + esc(m.tpl)
    + ') · ' + m.files.length + ' fichiers</div>').join("")
    : '<div class="recot">aucun scaffold genere - clique Generer ci-dessus</div>';
}

function renderRuns(){
  const rs = (STATE && STATE.runs) || [];
  $("#run-list").innerHTML = rs.length ? rs.map(r => {
    const st = r.status === "ok" ? "ok" : (r.status === "fail" ? "bad" : (r.status === "running" ? "run" : "idle"));
    const ex = (r.exit === undefined || r.exit === null) ? "..." : ("exit " + r.exit);
    return '<div class="run"><div class="rhead" onclick="this.nextElementSibling.classList.toggle(\'hide\')">'
      + '<span class="dot ' + st + '"></span> ' + esc(r.started) + " · " + esc(r.agent_name)
      + ' <span class="src">' + ex + '</span></div>'
      + '<pre class="rout hide">' + esc(r.output || "(en cours...)") + '</pre></div>';
  }).join("") : '<div class="recot">aucune execution - clique Run sur un agent</div>';
}

function renderCatalog(){
  $("#cat-list").innerHTML = CATALOG.oss.map(o =>
    '<div class="cat"><div class="ahead"><a href="' + esc(o.repo) + '" target="_blank"><b>'
    + esc(o.name) + '</b></a><span class="src">' + esc(o.category) + ' · ' + esc(o.lang)
    + '</span></div><div class="agoal">' + esc(o.desc) + '</div>'
    + '<div class="ameta">install: <code>' + esc(o.install) + '</code></div></div>').join("");
  $("#bp-list").innerHTML = CATALOG.blueprints.map(b =>
    '<div class="cat"><div class="ahead"><b>' + esc(b.name) + '</b><span class="src">'
    + esc(b.id) + '</span></div><div class="agoal">' + esc(b.desc) + '</div>'
    + '<div class="ameta">' + esc(b.commands.join(" ; ")) + '</div></div>').join("");
}

async function tick(){
  try{
    STATE = await api("/api/state");
    renderCards(); renderAgents(); renderTpls(); renderMade(); renderRuns();
    draw($("#ch1"), [SER("cpu"), SER("mem")], ["#26a69a", "#bb86fc"], 100);
    draw($("#ch2"), [SER("rx"), SER("tx")], ["#4fc3f7", "#ffb74d"], null);
  }catch(e){ toast(e.message, true); }
}

async function loadCatalog(){
  try{ CATALOG = await api("/api/catalog"); }
  catch(e){ toast(e.message, true); }
  fillBpSelect(); renderCatalog();
}

function fillBpSelect(){
  $("#f-bp").innerHTML = '<option value="">- aucun (auto par objectif/prompt) -</option>'
    + CATALOG.blueprints.map(b => '<option value="' + b.id + '">' + esc(b.name) + '</option>').join("");
}

async function runAgent(id){
  try{ await api("/api/agents/" + id + "/run", POST({})); toast("run lance: " + id); setTimeout(tick, 800); }
  catch(e){ toast(e.message, true); }
}

async function delAgent(id){
  if(!confirm("Supprimer l agent " + id + " ?")) return;
  try{ await api("/api/agents/" + id + "/delete", POST({})); toast("supprime: " + id); tick(); }
  catch(e){ toast(e.message, true); }
}

async function genTpl(id){
  const name = prompt("Nom du projet:", "mon-projet");
  if(!name) return;
  try{
    const r = await api("/api/scaffolds/create", POST({tpl: id, name: name}));
    toast("Scaffold OK: " + r.files.length + " fichier(s) dans " + r.dir);
    tick();
  }catch(e){ toast(e.message, true); }
}

function openModal(){ $("#modal-bg").classList.remove("hidden"); }
function closeModal(){ $("#modal-bg").classList.add("hidden"); EDIT_ID = null; }

function newAgent(){
  EDIT_ID = null;
  $("#modal-title").textContent = "Agent personnalise";
  $("#f-name").value = ""; $("#f-goal").value = ""; $("#f-prompt").value = "";
  $("#f-bp").value = ""; $("#f-iv").value = "0";
  $("#reco").innerHTML = "";
  openModal();
}

function editAgent(id){
  const a = ((STATE && STATE.agents) || []).find(x => x.id === id);
  if(!a) return;
  EDIT_ID = id;
  $("#modal-title").textContent = "Editer agent: " + id;
  $("#f-name").value = a.name; $("#f-goal").value = a.goal || "";
  $("#f-prompt").value = ""; $("#f-iv").value = a.interval || 0;
  $("#reco").innerHTML = "";
  openModal();
}

function pickBp(id){ $("#f-bp").value = id; toast("blueprint choisi: " + id); }

async function doReco(){
  const goal = $("#f-goal").value.trim() || $("#f-prompt").value.trim();
  if(!goal) return toast("ecris un objectif d abord", true);
  try{
    const r = await api("/api/agents/recommend", POST({goal: goal}));
    let html = "";
    if(r.blueprints.length){
      html += '<div class="recot">Blueprints locaux (score):</div>'
        + r.blueprints.map(b => '<button class="chip" onclick="pickBp(\'' + b.id + '\')">'
          + esc(b.name) + ' · ' + b.score + '</button>').join("");
    }
    if(r.oss.length){
      html += '<div class="recot">Agents open source matches:</div>'
        + r.oss.map(o => '<a class="chip oss" href="' + esc(o.repo) + '" target="_blank">'
          + esc(o.name) + ' ↗</a>').join("");
    }
    $("#reco").innerHTML = html || '<div class="recot">aucun match - reformule ton objectif</div>';
  }catch(e){ toast(e.message, true); }
}

async function saveAgent(){
  const payload = {
    name: $("#f-name").value.trim(),
    goal: $("#f-goal").value.trim(),
    prompt: $("#f-prompt").value.trim(),
    blueprint: $("#f-bp").value,
    interval: parseInt($("#f-iv").value || "0", 10),
    use_ollama: $("#f-ollama").checked
  };
  if(!payload.name) return toast("nom requis", true);
  try{
    if(EDIT_ID){
      await api("/api/agents/" + EDIT_ID + "/update", POST(payload));
      toast("agent mis a jour: " + EDIT_ID);
    }else{
      const r = await api("/api/agents/create", POST(payload));
      toast("agent cree: " + r.agent.id + " (" + r.agent.commands.length + " cmd, source " + r.agent.source + ")");
    }
    closeModal(); tick();
  }catch(e){ toast(e.message, true); }
}

document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".tab").forEach(t => t.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(x => x.classList.remove("on"));
    document.querySelectorAll(".tabbody").forEach(x => x.classList.remove("on"));
    t.classList.add("on");
    document.getElementById("tab-" + t.dataset.t).classList.add("on");
  }));
  $("#new-agent").addEventListener("click", newAgent);
  $("#btn-reco").addEventListener("click", doReco);
  $("#btn-save").addEventListener("click", saveAgent);
  $("#btn-close").addEventListener("click", closeModal);
  $("#modal-bg").addEventListener("click", e => { if(e.target.id === "modal-bg") closeModal(); });
  document.addEventListener("keydown", e => { if(e.key === "Escape") closeModal(); });
  loadCatalog();
  api("/api/ollama/check", POST({})).then(r => {
    $("#f-ollama").checked = !!r.available;
    $("#ollama-hint").textContent = r.available
      ? ("Ollama detecte: " + r.models.join(", "))
      : "Ollama absent - mode prompt-rules automatique";
  }).catch(() => { $("#ollama-hint").textContent = "Ollama absent - mode prompt-rules automatique"; });
  tick();
  setInterval(tick, 3000);
  setInterval(() => { $("#clock").textContent = new Date().toLocaleTimeString(); }, 1000);
});
</script>
</body>
</html>
"""

# ---------------- serveur ----------------
class Handler(BaseHTTPRequestHandler):
    server_version = "Nercel13"

    def log_message(self, fmt, *args):
        sys.stdout.write("[%s] %s\n" % (self.log_date_time_string(), fmt % args))
        sys.stdout.flush()

    def send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def read_body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0:
            return {}
        raw = self.rfile.read(n).decode("utf-8", "replace")
        try:
            return json.loads(raw)
        except Exception:
            raise ValueError("corps JSON invalide")

    def do_GET(self):
        try:
            path = self.path.split("?")[0]
            if path == "/":
                body = PAGE.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            elif path == "/api/health":
                self.send_json({"ok": True, "version": VERSION, "ts": now_iso()})
            elif path == "/api/state":
                self.send_json(state())
            elif path == "/api/catalog":
                self.send_json({"oss": OSS_CATALOG, "blueprints": BLUEPRINTS})
            elif path == "/api/scaffolds":
                self.send_json({"templates": scaffold_templates_public(),
                                "created": DATA["scaffolds_created"]})
            else:
                self.send_json({"error": "route inconnue: " + path,
                                "hint": "voir /api/state"}, 404)
        except Exception as e:
            try:
                self.send_json({"error": "erreur serveur: " + str(e)}, 500)
            except Exception:
                pass

    def do_POST(self):
        try:
            path = self.path.split("?")[0]
            try:
                payload = self.read_body()
            except ValueError as e:
                return self.send_json({"error": str(e)}, 400)
            m = re.match(r"^/api/agents/([a-z0-9_-]+)/(run|update|delete)$", path)
            if m:
                aid, action = m.group(1), m.group(2)
                if action == "run":
                    rec = run_agent(aid)
                    if rec is None:
                        return self.send_json({"error": "agent introuvable: " + aid}, 404)
                    return self.send_json({"ok": True, "run": rec})
                ag = next((a for a in DATA["agents"] if a["id"] == aid), None)
                if ag is None:
                    return self.send_json({"error": "agent introuvable: " + aid}, 404)
                if action == "delete":
                    with DATA_LOCK:
                        DATA["agents"].remove(ag)
                    save_data()
                    return self.send_json({"ok": True, "deleted": aid})
                update_agent(ag, payload)
                save_data()
                return self.send_json({"ok": True, "agent": ag})
            if path == "/api/agents/create":
                return self.send_json(agent_create(payload))
            if path == "/api/agents/recommend":
                return self.send_json(recommend(payload.get("goal") or payload.get("prompt") or ""))
            if path == "/api/ollama/check":
                ok, models = ollama_status()
                return self.send_json({"available": ok, "models": models})
            if path == "/api/scaffolds/create":
                return self.send_json(scaffold_create(payload))
            return self.send_json({"error": "route POST inconnue: " + path}, 404)
        except ValueError as e:
            self.send_json({"error": str(e)}, 400)
        except Exception as e:
            try:
                self.send_json({"error": "erreur serveur: " + str(e)}, 500)
            except Exception:
                pass

def main():
    load_data()
    threading.Thread(target=sampler, daemon=True).start()
    threading.Thread(target=scheduler, daemon=True).start()
    srv = ThreadingHTTPServer((HOST, PORT), Handler)
    print("Nercel 13 FORGE - http://%s:%d - data: %s" % (HOST, PORT, DATA_FILE))
    print("Agents: %d - OSS catalog: %d - Blueprints: %d - Scaffolds: %d" %
          (len(DATA["agents"]), len(OSS_CATALOG), len(BLUEPRINTS), len(SCAFFOLD_TEMPLATES)))
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("bye")

if __name__ == "__main__":
    main()
