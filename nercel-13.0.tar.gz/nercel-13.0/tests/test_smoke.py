"""Test smoke NERCEL 13 — exécuté par l'agent `tests` du dashboard."""
import unittest


class TestSmoke(unittest.TestCase):
    def test_python_fonctionne(self):
        self.assertTrue(True)

    def test_module_nercel13_importable(self):
        import ast
        with open("nercel13.py", encoding="utf-8") as fh:
            tree = ast.parse(fh.read(), "nercel13.py")
        # le module doit contenir les fonctions clés du FORGE
        names = {n.name for n in ast.walk(tree)
                 if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
        for expected in ("sampler", "run_agent", "agent_create", "state",
                         "scaffold_create", "recommend", "ollama_status"):
            self.assertIn(expected, names)

    def test_routes_json_garanti(self):
        """Le bug v11 (JSON.parse: unexpected character) est mort par
        construction : les routes inconnues renvoient du JSON, pas du HTML."""
        import ast
        with open("nercel13.py", encoding="utf-8") as fh:
            src = fh.read()
        # aucun send_error / page HTML d'erreur ne doit exister
        self.assertNotIn("send_error(", src)
        self.assertIn('self.send_json({"error": "route inconnue: "', src)


if __name__ == "__main__":
    unittest.main()
