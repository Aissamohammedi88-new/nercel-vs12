#!/usr/bin/env bash
# NERCEL 12 — Agent Deck : lanceur (stdlib uniquement, aucune installation)
set -e
cd "$(dirname "$0")"
python3 -m py_compile nercel12.py && echo "✓ nercel12 compilation OK"
echo "--- Agent Deck : http://127.0.0.1:5065 (Ctrl+C pour arrêter) ---"
exec python3 nercel12.py
