# NERCEL 12 — Agent Deck

Dashboard temps réel **style Grafana** + **agents réels** qui exécutent de vraies
commandes shell (vrai code de sortie, vrais logs). Zéro dépendance : **stdlib
Python uniquement**, rien à installer.

## Lancer

```bash
bash start12.sh
```

ou directement :

```bash
python3 nercel12.py
```

Puis ouvrir **http://127.0.0.1:5065** — arrêt avec **Ctrl+C**.
(Le port 5065 évite le port 5060, que Chrome refuse d'ouvrir par sécurité.)

## Ce que ça fait

- **Métriques réelles** lues dans `/proc` (pas de simulation) : CPU % (delta
  `/proc/stat`), mémoire (`/proc/meminfo`), disque, load, réseau ↓↑
  (`/proc/net/dev`) — échantillonnées toutes les 5 s, graphiques canvas live.
- **Agents réels** : exécution `subprocess` avec timeout 120 s, code de sortie,
  sortie console visible (clique sur une exécution dans le dashboard).
- **4 agents pré-installés** :
  - `compile` — `python3 -m py_compile *.py`
  - `tests` — `python3 -m unittest discover -s tests -v`
  - `deps` — `python3 -m pip check` (auto toutes les heures)
  - `docs` — vérifie la présence des fichiers web du dossier
- **Créer / éditer / supprimer** des agents depuis le bouton **+ Nouvel agent** :
  nom, intervalle auto (0 = manuel), commandes une par ligne.
- Les agents avec `intervalle > 0` tournent tout seuls en arrière-plan.

## API

| Route | Méthode | Effet |
|---|---|---|
| `/api/health` | GET | état du service |
| `/api/state` | GET | snapshot métriques + séries + agents + runs |
| `/api/agents/create` | POST | créer un agent |
| `/api/agents/<id>/run` | POST | lancer un agent |
| `/api/agents/<id>/update` | POST | modifier un agent |
| `/api/agents/<id>/delete` | POST | supprimer un agent |

## Fichiers

- `nercel12.py` — tout le service (backend + dashboard embarqué)
- `start12.sh` — lanceur (compile puis démarre)
- `tests/test_smoke.py` — test de base exécuté par l'agent `tests`
- `nercel12_data.json` — créé automatiquement : tes agents + historique des runs

## Configuration (variables d'environnement)

- `NERCEL12_PORT` (défaut `5065` — 5060 est bloqué par les navigateurs),
  `NERCEL12_HOST` (défaut `127.0.0.1`).

## 100 % additif

Ce dossier ne touche à aucun fichier existant : pose-le où tu veux (par exemple
à côté de ta v10/v11) et lance-le — tes autres versions restent intactes.
