#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NERCEL 12 — Agent Deck
Dashboard temps reel style Grafana + agents qui executent de VRAIES commandes.
100% additif : aucun fichier existant n'est modifie.
Stdlib uniquement — aucune installation necessaire.

Lancement :  python3 nercel12.py   (ou bash start12.sh)
Dashboard  :  http://127.0.0.1:5060
Arret      :  Ctrl+C
"""

import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

VERSION = "12.0"
HOST = os.environ.get("NERCEL12_HOST", "127.0.0.1")
PORT = int(os.environ.get("NERCEL12_PORT", "5065"))   # 5060 est bloqué par Chrome (port SIP)
ROOT = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(ROOT, "nercel12_data.json")
START_TS = time.time()

# ============================================================
# 1. METRIQUES REELLES (lues dans /proc — pas de simulation)
# ============================================================

def read_cpu_ticks():
    with open("/proc/stat") as fh:
        parts = fh.readline().split()
    vals = [int(x) for x in parts[1:8]]
    idle = vals[3] + vals[4]
    return idle, sum(vals)

def mem_percent():
    d = {}
    for line in open("/proc/meminfo"):
        k, v = line.split(":", 1)
        if k in ("MemTotal", "MemAvailable"):
            d[k] = int(v.strip().split()[0])
    used = d["MemTotal"] - d["MemAvailable"]
    return round(used * 100.0 / d["MemTotal"], 1), round(used / 1024), round(d["MemTotal"] / 1024)

def net_bytes():
    rx = tx = 0
    for line in open("/proc/net/dev"):
        if ":" not in line:
            continue
        iface, rest = line.split(":", 1)
        if iface.strip() == "lo":
            continue
        cols = rest.split()
        rx += int(cols[0])
        tx += int(cols[8])
    return rx, tx

MAX_POINTS = 300
SERIES = {"cpu": [], "mem": [], "net_rx": [], "net_tx": [], "ts": []}
_prev_cpu = read_cpu_ticks()
_prev_net = net_bytes()
_prev_t = time.time()

def sampler():
    """Echantillonne les vraies metriques toutes les 5 secondes."""
    global _prev_cpu, _prev_net, _prev_t
    while True:
        time.sleep(5)
        try:
            idle, total = read_cpu_ticks()
            rx, tx = net_bytes()
            now = time.time()
            dt = max(now - _prev_t, 0.001)
            didle = idle - _prev_cpu[0]
            dtotal = max(total - _prev_cpu[1], 1)
            cpu = round((1 - didle / dtotal) * 100, 1)
            memp, _, _ = mem_percent()
            rxps = max(rx - _prev_net[0], 0) / dt / 1024.0
            txps = max(tx - _prev_net[1], 0) / dt / 1024.0
            _prev_cpu, _prev_net, _prev_t = (idle, total), (rx, tx), now
            for key, val in (("cpu", cpu), ("mem", memp),
                             ("net_rx", round(rxps, 1)), ("net_tx", round(txps, 1)),
                             ("ts", now)):
                SERIES[key].append(val)
                if len(SERIES[key]) > MAX_POINTS:
                    SERIES[key].pop(0)
        except Exception as exc:
            sys.stdout.write("[sampler] %s\n" % exc)

def snapshot():
    memp, usedmb, totalmb = mem_percent()
    du = shutil.disk_usage(ROOT)
    files = [f for f in os.listdir(ROOT) if os.path.isfile(os.path.join(ROOT, f))]
    py = [f for f in files if f.endswith(".py")]
    return {
        "cpu": SERIES["cpu"][-1] if SERIES["cpu"] else None,
        "mem": memp,
        "mem_used_mb": usedmb,
        "mem_total_mb": totalmb,
        "disk_pct": round(du.used * 100.0 / du.total, 1),
        "disk_used_gb": round(du.used / (1024 ** 3), 1),
        "disk_total_gb": round(du.total / (1024 ** 3), 1),
        "load1": round(os.getloadavg()[0], 2),
        "net_rx": SERIES["net_rx"][-1] if SERIES["net_rx"] else None,
        "net_tx": SERIES["net_tx"][-1] if SERIES["net_tx"] else None,
        "files": len(files),
        "py_files": len(py),
    }

# ============================================================
# 2. AGENTS REELS (subprocess, code de sortie, logs persistes)
# ============================================================

DEFAULT_AGENTS = [
    {"id": "compile", "name": "Compiler", "interval": 0,
     "commands": ["python3 -m py_compile *.py 2>&1"]},
    {"id": "tests", "name": "Tests", "interval": 0,
     "commands": ["python3 -m unittest discover -s tests -v 2>&1"]},
    {"id": "deps", "name": "Deps Check", "interval": 3600,
     "commands": ["python3 -m pip check 2>&1"]},
    {"id": "docs", "name": "Docs Check", "interval": 0,
     "commands": ["ls -la *.html *.css *.js 2>&1"]},
]

AGENTS = {}
RUNS = []
RUN_LOCK = threading.Lock()

def load_data():
    global AGENTS, RUNS
    if os.path.isfile(DATA_FILE):
        try:
            with open(DATA_FILE, encoding="utf-8") as fh:
                raw = json.load(fh)
            AGENTS = {a["id"]: a for a in raw.get("agents", [])}
            RUNS = raw.get("runs", [])
            return
        except Exception as exc:
            sys.stdout.write("[data] rechargement impossible: %s\n" % exc)
    AGENTS = {a["id"]: dict(a) for a in DEFAULT_AGENTS}
    RUNS = []
    save_data()

def save_data():
    tmp = DATA_FILE + ".tmp"
    payload = {
        "agents": [{k: v for k, v in a.items() if not k.startswith("_")}
                   for a in AGENTS.values()],
        "runs": RUNS[:30],
    }
    try:
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=2)
        os.replace(tmp, DATA_FILE)
    except Exception as exc:
        sys.stdout.write("[data] sauvegarde impossible: %s\n" % exc)

def slugify(text):
    out = re.sub(r"[^a-z0-9_-]", "-", text.lower()).strip("-")[:40]
    return out or "agent"

def run_agent(agent_id):
    agent = AGENTS.get(agent_id)
    if not agent:
        return None
    run_id = "%s-%d" % (agent_id, int(time.time() * 1000))
    rec = {"id": run_id, "agent": agent_id, "name": agent["name"],
           "start": time.time(), "end": None, "status": "running",
           "code": None, "output": ""}
    with RUN_LOCK:
        RUNS.insert(0, rec)
        del RUNS[50:]
    threading.Thread(target=_exec_agent, args=(agent, rec), daemon=True).start()
    return run_id

def _exec_agent(agent, rec):
    outs = []
    code = 0
    for cmd in agent.get("commands", []):
        try:
            proc = subprocess.run(cmd, shell=True, cwd=ROOT,
                                  capture_output=True, text=True, timeout=120)
            code = proc.returncode
            outs.append("$ %s\n%s%s" % (cmd, proc.stdout, proc.stderr))
        except subprocess.TimeoutExpired:
            code = 124
            outs.append("$ %s\nTIMEOUT (120s)" % cmd)
        except Exception as exc:
            code = 1
            outs.append("$ %s\nERREUR: %s" % (cmd, exc))
        if code != 0:
            break
    rec["end"] = time.time()
    rec["code"] = code
    rec["status"] = "ok" if code == 0 else "fail"
    rec["output"] = "\n".join(outs)[-4000:]
    agent["last_status"] = rec["status"]
    agent["last_run"] = rec["end"]
    agent["last_code"] = code
    save_data()

def scheduler():
    """Execute automatiquement les agents avec interval > 0."""
    while True:
        time.sleep(10)
        now = time.time()
        for aid, agent in list(AGENTS.items()):
            iv = agent.get("interval") or 0
            if iv <= 0:
                continue
            if now - agent.get("_last_auto", 0) >= iv:
                agent["_last_auto"] = now
                sys.stdout.write("[scheduler] auto-run %s\n" % aid)
                run_agent(aid)

def agent_create(body):
    name = str(body.get("name") or "").strip()
    cmds = body.get("commands") or []
    if isinstance(cmds, str):
        cmds = [c.strip() for c in cmds.split("\n") if c.strip()]
    cmds = [str(c) for c in cmds if str(c).strip()]
    if not name:
        return {"ok": False, "error": "nom requis"}
    if not cmds:
        return {"ok": False, "error": "au moins une commande requise"}
    aid = slugify(name)
    base = aid
    n = 2
    while aid in AGENTS:
        aid = "%s-%d" % (base, n)
        n += 1
    try:
        interval = max(0, int(body.get("interval") or 0))
    except (TypeError, ValueError):
        interval = 0
    AGENTS[aid] = {"id": aid, "name": name, "commands": cmds, "interval": interval}
    save_data()
    return {"ok": True, "id": aid}

def agent_update(aid, body):
    agent = AGENTS.get(aid)
    if not agent:
        return {"ok": False, "error": "agent introuvable: %s" % aid}
    if body.get("name"):
        agent["name"] = str(body["name"]).strip()
    cmds = body.get("commands")
    if cmds is not None:
        if isinstance(cmds, str):
            cmds = [c.strip() for c in cmds.split("\n") if c.strip()]
        agent["commands"] = [str(c) for c in cmds if str(c).strip()]
    if body.get("interval") is not None:
        try:
            agent["interval"] = max(0, int(body["interval"]))
        except (TypeError, ValueError):
            pass
    save_data()
    return {"ok": True}

def agent_delete(aid):
    if aid not in AGENTS:
        return {"ok": False, "error": "agent introuvable: %s" % aid}
    del AGENTS[aid]
    save_data()
    return {"ok": True}

def state():
    n = 150
    return {
        "ok": True,
        "version": VERSION,
        "project": ROOT,
        "uptime": time.time() - START_TS,
        "snapshot": snapshot(),
        "series": {k: v[-n:] for k, v in SERIES.items()},
        "agents": [{k: v for k, v in a.items() if not k.startswith("_")}
                   for a in AGENTS.values()],
        "runs": [dict(r) for r in RUNS[:20]],
    }

# ============================================================
# 3. SERVEUR HTTP
# ============================================================

class Handler(BaseHTTPRequestHandler):
    server_version = "Nercel12/" + VERSION

    def log_message(self, *args):
        pass

    def _json(self, obj, code=200):
        raw = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def _html(self):
        raw = PAGE.encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        path = urlparse(self.path).path
        if path in ("/", "/index.html"):
            return self._html()
        if path == "/favicon.ico":
            self.send_response(204)
            self.end_headers()
            return
        if path == "/api/health":
            return self._json({"ok": True, "version": VERSION, "port": PORT})
        if path == "/api/state":
            return self._json(state())
        return self._json({"ok": False, "error": "404"}, 404)

    def do_POST(self):
        path = urlparse(self.path).path
        try:
            length = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(length) if length else b"{}"
            body = json.loads(raw.decode() or "{}")
        except Exception as exc:
            return self._json({"ok": False, "error": "json invalide: %s" % exc}, 400)
        try:
            if path == "/api/agents/create":
                return self._json(agent_create(body))
            match = re.match(r"^/api/agents/([a-z0-9_-]+)/(run|update|delete)$", path)
            if match:
                aid, action = match.group(1), match.group(2)
                if action == "run":
                    if run_agent(aid) is None:
                        return self._json({"ok": False, "error": "agent introuvable"}, 404)
                    return self._json({"ok": True})
                if action == "update":
                    return self._json(agent_update(aid, body))
                if action == "delete":
                    return self._json(agent_delete(aid))
            return self._json({"ok": False, "error": "route inconnue"}, 404)
        except Exception as exc:
            return self._json({"ok": False, "error": str(exc)}, 500)

# ============================================================
# 4. DASHBOARD (style Grafana — canvas, sans lib externe)
# ============================================================

PAGE = r"""<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>NERCEL 12 — Agent Deck</title>
<style>
:root{
  --bg:#0b0f14; --panel:#111823; --border:#1f2a3a; --txt:#d7e2ee;
  --muted:#8aa0b8; --green:#3ddc84; --warn:#ffb454; --bad:#ff6b6b;
  --blue:#58a6ff; --orange:#ff7b3a;
}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--txt);
  font:14px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
header{position:sticky;top:0;z-index:10;display:flex;justify-content:space-between;
  align-items:center;padding:12px 20px;background:#0d1320ee;
  border-bottom:1px solid var(--border);backdrop-filter:blur(6px)}
.brand{font-size:18px;font-weight:700;letter-spacing:.5px}
.brand b{color:var(--orange)}
.pulse{display:inline-block;width:10px;height:10px;border-radius:50%;
  background:var(--green);margin-right:8px;box-shadow:0 0 8px var(--green);
  animation:pl 2s infinite}
@keyframes pl{50%{opacity:.35}}
.meta{color:var(--muted);font-size:13px}
main{max-width:1200px;margin:0 auto;padding:18px}
.statrow{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}
.stat{background:var(--panel);border:1px solid var(--border);border-radius:10px;padding:12px 14px}
.stat .lab{color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.8px}
.stat .val{font-size:26px;font-weight:700;margin:4px 0 8px}
.stat .bar{height:6px;border-radius:3px;background:#0a0e13;overflow:hidden}
.stat .bar i{display:block;height:100%;border-radius:3px;background:var(--green)}
.stat.w .val{color:var(--warn)} .stat.w .bar i{background:var(--warn)}
.stat.b .val{color:var(--bad)} .stat.b .bar i{background:var(--bad)}
.chartsrow{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:12px 0}
@media(max-width:800px){.chartsrow{grid-template-columns:1fr}}
.panel{background:var(--panel);border:1px solid var(--border);border-radius:10px;padding:14px}
.ptitle{font-weight:700;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center}
.prow{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}
canvas{width:100%;height:180px;display:block}
.legend{display:flex;gap:12px;font-weight:400;font-size:12px;color:var(--muted)}
.legend i{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:4px}
.aggrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:12px}
.ag{background:#0d1420;border:1px solid var(--border);border-radius:10px;padding:12px}
.ag .nm{font-weight:700;font-size:15px;display:flex;align-items:center;gap:8px}
.dot{width:9px;height:9px;border-radius:50%;background:#3a4a60;flex:none}
.dot.ok{background:var(--green);box-shadow:0 0 6px var(--green)}
.dot.fail{background:var(--bad);box-shadow:0 0 6px var(--bad)}
.dot.running{background:var(--warn);animation:pl 1s infinite}
.ag .role{color:var(--muted);font-size:12px;margin:6px 0}
.ag .acts{display:flex;gap:6px;margin-top:10px;flex-wrap:wrap}
.btn{background:var(--orange);color:#fff;border:0;border-radius:8px;
  padding:7px 14px;font-weight:600;cursor:pointer;font-size:13px}
.btn:hover{filter:brightness(1.1)}
.btn.ghost{background:transparent;border:1px solid var(--border);color:var(--muted)}
.mini{background:#1c2635;color:var(--txt);border:1px solid var(--border);
  border-radius:7px;padding:5px 10px;font-size:12px;cursor:pointer}
.mini:hover{border-color:var(--muted)}
.mini.danger{color:var(--bad)}
.badge{font-size:11px;color:var(--muted);border:1px solid var(--border);
  border-radius:20px;padding:2px 8px}
.runrow{border-top:1px solid var(--border);padding:8px 4px;cursor:pointer;
  display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.runrow:hover{background:#0d1420}
.runrow .rname{font-weight:600;min-width:120px}
.runrow .rtime,.runrow .rdur{color:var(--muted);font-size:12px}
.runrow pre{width:100%;background:#0a0e13;border:1px solid var(--border);
  border-radius:8px;padding:10px;max-height:200px;overflow:auto;
  font:12px/1.45 ui-monospace,monospace;white-space:pre-wrap}
.hidden{display:none!important}
#overlay{position:fixed;inset:0;background:#000a;display:flex;
  align-items:center;justify-content:center;z-index:50}
.modal{background:var(--panel);border:1px solid var(--border);border-radius:12px;
  padding:20px;width:min(560px,92vw)}
.modal label{display:block;color:var(--muted);font-size:12px;margin:12px 0 4px}
.modal input,.modal textarea{width:100%;background:#0a0e13;color:var(--txt);
  border:1px solid var(--border);border-radius:8px;padding:8px 10px;
  font:13px ui-monospace,monospace}
.mbtns{display:flex;gap:10px;margin-top:16px;justify-content:flex-end}
#toast{position:fixed;bottom:18px;left:50%;transform:translateX(-50%);
  background:#152238;border:1px solid var(--border);color:var(--txt);
  padding:10px 18px;border-radius:10px;opacity:0;transition:opacity .3s;z-index:60}
#toast.show{opacity:1}
</style>
</head>
<body>
<header>
  <div class="brand"><span class="pulse"></span>NERCEL <b>12</b> · Agent Deck</div>
  <div class="meta"><span id="proj"></span> · up <span id="uptime">—</span> · v<span id="ver">12</span></div>
</header>
<main>
  <section class="statrow" id="stats"></section>
  <section class="chartsrow">
    <div class="panel">
      <div class="ptitle">CPU &amp; Mémoire
        <span class="legend"><span><i style="background:var(--blue)"></i>cpu</span>
        <span><i style="background:var(--orange)"></i>mem</span></span>
      </div>
      <canvas id="c1"></canvas>
    </div>
    <div class="panel">
      <div class="ptitle">Réseau KB/s
        <span class="legend"><span><i style="background:var(--green)"></i>rx</span>
        <span><i style="background:var(--blue)"></i>tx</span></span>
      </div>
      <canvas id="c2"></canvas>
    </div>
  </section>
  <section class="panel" style="margin-bottom:12px">
    <div class="prow">
      <div class="ptitle">Agents <span id="agcount" class="badge"></span></div>
      <button class="btn" onclick="openModal()">+ Nouvel agent</button>
    </div>
    <div id="agents" class="aggrid"></div>
  </section>
  <section class="panel">
    <div class="ptitle">Exécutions récentes <span class="badge">clic = voir la sortie</span></div>
    <div id="runs"></div>
  </section>
</main>
<div id="overlay" class="hidden">
  <div class="modal">
    <div class="ptitle" id="modal-title">Nouvel agent</div>
    <label>Nom</label>
    <input id="ag-name" placeholder="deploy-check">
    <label>Intervalle auto en secondes (0 = manuel)</label>
    <input id="ag-interval" type="number" min="0" value="0">
    <label>Commandes réelles — une par ligne</label>
    <textarea id="ag-cmds" rows="6" placeholder="echo hello&#10;python3 -m py_compile *.py"></textarea>
    <div class="mbtns">
      <button class="btn ghost" onclick="closeModal()">Annuler</button>
      <button class="btn" onclick="saveAgent()">Enregistrer</button>
    </div>
  </div>
</div>
<div id="toast"></div>
<script>
let S = null, editing = null;
const $ = s => document.querySelector(s);

async function api(path, body){
  const opt = body ? {method:'POST', headers:{'Content-Type':'application/json'},
                      body: JSON.stringify(body)} : {};
  const r = await fetch(path, opt);
  return r.json();
}
function esc(s){ return String(s).replace(/[&<>"']/g,
  c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function fmtDur(sec){ sec = Math.max(0, Math.round(sec));
  if (sec < 60) return sec + 's';
  return Math.floor(sec/60) + 'm' + (sec%60) + 's'; }
function fmtAgo(ts){ return ts ? 'il y a ' + fmtDur(Date.now()/1000 - ts) : 'jamais lancé'; }
let toastTimer = null;
function toast(msg){
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2500);
}

function statHtml(label, val, pct){
  const cls = pct >= 85 ? 'b' : (pct >= 60 ? 'w' : '');
  const p = pct == null ? 0 : Math.min(100, pct);
  return '<div class="stat ' + cls + '"><div class="lab">' + label + '</div>' +
         '<div class="val">' + val + '</div>' +
         '<div class="bar"><i style="width:' + p + '%"></i></div></div>';
}
function renderStats(snap){
  const f = v => (v == null ? '—' : v);
  let h = '';
  h += statHtml('CPU', f(snap.cpu) + '%', snap.cpu);
  h += statHtml('Mémoire', f(snap.mem) + '%', snap.mem);
  h += statHtml('Disque', f(snap.disk_pct) + '%', snap.disk_pct);
  h += statHtml('Load 1m', f(snap.load1), Math.min(100, (snap.load1||0)*25));
  h += statHtml('Réseau ↓', f(snap.net_rx) + ' KB/s', 0);
  h += statHtml('Réseau ↑', f(snap.net_tx) + ' KB/s', 0);
  h += statHtml('Fichiers', snap.files + ' <small>(' + snap.py_files + ' .py)</small>', 0);
  h += statHtml('RAM MB', snap.mem_used_mb + '/' + snap.mem_total_mb, snap.mem);
  $('#stats').innerHTML = h;
}

function drawChart(cv, seriesList, yMax){
  const ctx = cv.getContext('2d');
  const W = cv.width = cv.offsetWidth * (window.devicePixelRatio || 1);
  const H = cv.height = cv.offsetHeight * (window.devicePixelRatio || 1);
  ctx.clearRect(0, 0, W, H);
  ctx.strokeStyle = '#1f2a3a'; ctx.lineWidth = 1;
  for (let i = 1; i < 4; i++){
    const y = H * i / 4;
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
  }
  if (yMax == null){
    let mx = 1;
    seriesList.forEach(s => s.data.forEach(v => { if (v > mx) mx = v; }));
    yMax = mx * 1.2;
  }
  seriesList.forEach(s => {
    const data = s.data, n = data.length;
    if (n < 2) return;
    ctx.strokeStyle = s.color; ctx.lineWidth = 2 * (window.devicePixelRatio || 1);
    ctx.beginPath();
    for (let i = 0; i < n; i++){
      const x = i / (n - 1) * W;
      const y = H - Math.min(data[i] / yMax, 1) * H * 0.95;
      i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
    }
    ctx.stroke();
    ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.closePath();
    ctx.globalAlpha = 0.08; ctx.fillStyle = s.color; ctx.fill(); ctx.globalAlpha = 1;
  });
}

function dotClass(a){
  if (a.last_status === 'ok') return 'ok';
  if (a.last_status === 'fail') return 'fail';
  return '';
}
function renderAgents(agents){
  $('#agcount').textContent = agents.length;
  $('#agents').innerHTML = agents.map(a =>
    '<div class="ag">' +
      '<div class="nm"><span class="dot ' + dotClass(a) + '"></span>' + esc(a.name) + '</div>' +
      '<div class="role">' + a.commands.length + ' commande(s) · ' + fmtAgo(a.last_run) +
        ' · <span class="badge">' + (a.interval ? 'auto ' + a.interval + 's' : 'manuel') + '</span></div>' +
      '<div class="role mono">' + esc(a.commands[0]) + (a.commands.length > 1 ? ' …' : '') + '</div>' +
      '<div class="acts">' +
        '<button class="mini" onclick="runAgent(\'' + a.id + '\')">Lancer</button>' +
        '<button class="mini" onclick="openModal(\'' + a.id + '\')">Éditer</button>' +
        '<button class="mini danger" onclick="delAgent(\'' + a.id + '\')">Supprimer</button>' +
      '</div>' +
    '</div>').join('');
}
function renderRuns(runs){
  $('#runs').innerHTML = runs.length ? runs.map(r => {
    const dur = r.end ? fmtDur(r.end - r.start) : '…';
    const tm = new Date(r.start * 1000).toLocaleTimeString('fr-FR');
    return '<div class="runrow" onclick="toggleOut(\'' + r.id + '\')">' +
      '<span class="dot ' + r.status + '"></span>' +
      '<span class="rname">' + esc(r.name) + '</span>' +
      '<span class="rtime">' + tm + '</span>' +
      '<span class="rdur">' + dur + ' · ' + (r.code == null ? '…' : 'exit ' + r.code) + '</span>' +
      '<pre id="out-' + esc(r.id) + '" class="hidden">' + esc(r.output || '…') + '</pre>' +
    '</div>';
  }).join('') : '<div class="role" style="color:var(--muted);padding:8px 0">Aucune exécution — clique « Lancer » sur un agent.</div>';
}
function toggleOut(id){ $('#out-' + CSS.escape(id)).classList.toggle('hidden'); }

async function runAgent(id){
  const res = await api('/api/agents/' + id + '/run', {});
  toast(res.ok ? 'Agent lancé : ' + id : (res.error || 'erreur'));
  setTimeout(refresh, 800);
}
async function delAgent(id){
  if (!confirm('Supprimer l\'agent ' + id + ' ?')) return;
  const res = await api('/api/agents/' + id + '/delete', {});
  toast(res.ok ? 'Supprimé' : (res.error || 'erreur'));
  refresh();
}
function openModal(id){
  editing = id || null;
  const a = id ? S.agents.find(x => x.id === id) : null;
  $('#modal-title').textContent = a ? 'Éditer : ' + a.name : 'Nouvel agent';
  $('#ag-name').value = a ? a.name : '';
  $('#ag-interval').value = a ? (a.interval || 0) : 0;
  $('#ag-cmds').value = a ? a.commands.join('\n') : '';
  $('#overlay').classList.remove('hidden');
}
function closeModal(){ $('#overlay').classList.add('hidden'); editing = null; }
async function saveAgent(){
  const payload = {
    name: $('#ag-name').value.trim(),
    interval: parseInt($('#ag-interval').value || '0', 10),
    commands: $('#ag-cmds').value.split('\n').map(s => s.trim()).filter(Boolean),
  };
  if (!payload.name) return toast('Nom requis');
  if (!payload.commands.length) return toast('Au moins une commande');
  const res = editing
    ? await api('/api/agents/' + editing + '/update', payload)
    : await api('/api/agents/create', payload);
  toast(res.ok ? 'Agent enregistré' : (res.error || 'erreur'));
  closeModal();
  refresh();
}

async function refresh(){
  try {
    S = await api('/api/state');
    if (!S.ok) return;
    $('#proj').textContent = S.project;
    $('#uptime').textContent = fmtDur(S.uptime);
    $('#ver').textContent = S.version;
    renderStats(S.snapshot);
    drawChart($('#c1'), [
      {data: S.series.cpu, color: '#58a6ff'},
      {data: S.series.mem, color: '#ff7b3a'},
    ], 100);
    drawChart($('#c2'), [
      {data: S.series.net_rx, color: '#3ddc84'},
      {data: S.series.net_tx, color: '#58a6ff'},
    ], null);
    renderAgents(S.agents);
    renderRuns(S.runs);
  } catch (e) { /* serveur momentanement indisponible */ }
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });
refresh();
setInterval(refresh, 3000);
</script>
</body>
</html>"""

# ============================================================
# 5. DEMARRAGE
# ============================================================

def main():
    load_data()
    threading.Thread(target=sampler, daemon=True).start()
    threading.Thread(target=scheduler, daemon=True).start()
    srv = ThreadingHTTPServer((HOST, PORT), Handler)
    print("")
    print("  ================================================")
    print("   NERCEL %s — Agent Deck" % VERSION)
    print("  ================================================")
    print("   Dashboard : http://%s:%d" % (HOST, PORT))
    print("   Dossier   : %s" % ROOT)
    print("   Agents    : %s" % ", ".join(AGENTS.keys()))
    print("   Metriques : REELLES (/proc) — agents : subprocess reels")
    print("   Donnees   : %s" % DATA_FILE)
    print("   Arret     : Ctrl+C")
    print("  ================================================")
    print("")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n[nercel12] arret propre.")
        srv.server_close()

if __name__ == "__main__":
    main()
