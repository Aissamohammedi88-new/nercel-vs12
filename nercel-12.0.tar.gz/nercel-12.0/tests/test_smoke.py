"""Test smoke NERCEL 12 — exécuté par l'agent `tests` du dashboard."""
import unittest


class TestSmoke(unittest.TestCase):
    def test_python_fonctionne(self):
        self.assertTrue(True)

    def test_module_nercel12_importable(self):
        import ast
        with open("nercel12.py", encoding="utf-8") as fh:
            tree = ast.parse(fh.read(), "nercel12.py")
        # le module doit contenir les fonctions clés du deck
        names = {n.name for n in ast.walk(tree)
                 if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
        for expected in ("sampler", "snapshot", "run_agent", "agent_create", "state"):
            self.assertIn(expected, names)


if __name__ == "__main__":
    unittest.main()
